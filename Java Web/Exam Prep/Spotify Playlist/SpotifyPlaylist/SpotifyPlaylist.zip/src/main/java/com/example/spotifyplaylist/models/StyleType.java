package com.example.spotifyplaylist.models;

public enum StyleType {
    POP, ROCK, JAZZ
}
