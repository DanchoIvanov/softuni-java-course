package com.example.jsonex.cardealer.entities.supplier;

public class SupplierImportDTO {
    private String name;
    private boolean isImporter;

    public String getName() {
        return name;
    }

    public boolean isImporter() {
        return isImporter;
    }
}
