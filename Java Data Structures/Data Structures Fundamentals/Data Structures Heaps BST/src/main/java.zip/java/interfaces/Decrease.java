package interfaces;

public interface Decrease<E> {
    void decrease();
}
